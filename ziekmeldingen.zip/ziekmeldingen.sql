-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 07 jun 2020 om 20:02
-- Serverversie: 10.4.6-MariaDB
-- PHP-versie: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ziekmeldingen`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inlog`
--

DROP TABLE IF EXISTS `inlog`;
CREATE TABLE `inlog` (
  `Iid` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Wachtwoord` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `inlog`
--

INSERT INTO `inlog` (`Iid`, `Username`, `Wachtwoord`) VALUES
(1, 'Admin', 'Admin');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `registratie`
--

DROP TABLE IF EXISTS `registratie`;
CREATE TABLE `registratie` (
  `Sid` int(11) NOT NULL,
  `Naam` varchar(100) NOT NULL,
  `leeftijd` varchar(10) NOT NULL,
  `telefoonnummer` varchar(50) NOT NULL,
  `woonplaats` varchar(50) NOT NULL,
  `Ziekmelding` varchar(50) NOT NULL,
  `Ziektedatum` date NOT NULL,
  `betermelddatum` date NOT NULL,
  `Opmerking` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `registratie`
--

INSERT INTO `registratie` (`Sid`, `Naam`, `leeftijd`, `telefoonnummer`, `woonplaats`, `Ziekmelding`, `Ziektedatum`, `betermelddatum`, `Opmerking`) VALUES
(6, 'Luuk Beks', '17', '0653782197', 'Wouw', 'beter', '2020-10-15', '2020-10-17', '---'),
(7, 'Jeroen De Mooij', '18', '0658711932', 'Roosendaal', 'ziek', '2020-06-24', '0000-00-00', 'Corona'),
(8, 'Bere Kanters', '18', '0653782196', 'Roosendaal', 'beter', '2020-07-31', '2020-08-02', 'gezond'),
(9, 'jurgen verhagen', '26', '0658785485', 'heijningen', 'ziek', '2020-03-11', '0000-00-00', 'buikpijn');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `inlog`
--
ALTER TABLE `inlog`
  ADD PRIMARY KEY (`Iid`);

--
-- Indexen voor tabel `registratie`
--
ALTER TABLE `registratie`
  ADD PRIMARY KEY (`Sid`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `inlog`
--
ALTER TABLE `inlog`
  MODIFY `Iid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `registratie`
--
ALTER TABLE `registratie`
  MODIFY `Sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
