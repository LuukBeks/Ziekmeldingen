<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>meld je hier aan!</title>
    <link rel="stylesheet" type="text/css" href="2de.css">

</head>
<body>
<div id="btn2">
    <a href="ziekmelden.php">
        <button>alle leerlingen</button>
    </a>
</div>
    <h1>Aanmelden</h1>
    <div id="Log">
    <form method="POST">
        <h5>Naam: </h5><input type="text" placeholder="type here..." name="TxtNaam"></br>
        <h5>leeftijd: </h5><input type="text" placeholder="type here..." name="Txtleeftijd"></br>
        <h5>telefoonnummer: </h5><input type="text" placeholder="type here..." name="Txttelefoonnummer"></br>
        <h5>woonplaats: </h5><input type="text" placeholder="type here..." name="Txtwoonplaats"></br>
        <button type="submit" id="btn" name="btnSave">aanmelden</button>
    

    </form>
    </div>
    <?php


    $host = "localhost";
    $dbnaam = "ziekmeldingen";
    $gebruiker = "root";
    $wachtwoord = "";

    try{
        $con = new PDO("mysql:host=$host;dbname=$dbnaam", $gebruiker, $wachtwoord);
    }catch(PDOException $ex){

    echo "<hr/>";
    echo "ERROR: Verbinding mislukt: $ex";
    echo "<hr/>";
    }


    if(isset($_POST["btnSave"])){

        $Naam = $_POST["TxtNaam"];
        $leeftijd = $_POST["Txtleeftijd"];
        $telefoonnummer = $_POST["Txttelefoonnummer"];
        $woonplaats = $_POST["Txtwoonplaats"];
        

        $query = "INSERT INTO registratie (Naam, leeftijd, telefoonnummer, woonplaats) VALUES ".
            "('$Naam', '$leeftijd', '$telefoonnummer', '$woonplaats')";

        $stm = $con->prepare($query);

        if($stm->execute()){
            echo "Succesvol verzonden!";
        } else {
            echo "Error mislukt";
        }
    }
    ?>
</body>
</html>


