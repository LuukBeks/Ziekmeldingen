<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Alle leerlingen</title>
    <link rel="stylesheet" type="text/css" href="2de.css">
</head>
<body>
<div id="btn2">
    <a href="ziekmelden.php">
        <button>alle leerlingen</button>
    </a>
</div>
<div id="btn2">
    <a href="login.php">
        <button>Alle zieken vandaag</button>
    </a>
</div>
<?php


$host = "localhost";
$dbnaam = "ziekmeldingen";
$gebruiker = "root";
$wachtwoord = "";

$conn = new PDO("mysql:host=$host;dbname=$dbnaam", "$gebruiker", "$wachtwoord");

$id = $_GET['id'];
if(isset($_POST['btnUpdate']))
{
$Naam = $_POST['txtNaam'];
$leeftijd = $_POST['txtleeftijd'];
$telefoonnummer = $_POST['txttelefoonnummer'];
$woonplaats = $_POST['txtwoonplaats'];
$Ziekmelding = $_POST['txtZiekmelding'];
$Ziektedatum = $_POST['txtZiektedatum'];
$betermelddatum = $_POST['txtbetermelddatum'];
$Opmerking = $_POST['txtOpmerking'];
$query = "UPDATE registratie SET Naam = '$Naam', leeftijd = '$leeftijd', telefoonnummer = '$telefoonnummer', 
woonplaats = '$woonplaats', Ziekmelding = '$Ziekmelding', Ziektedatum = '$Ziektedatum', betermelddatum = '$betermelddatum', Opmerking = '$Opmerking' WHERE Sid = '$id'";
$stm = $conn->prepare($query);
if($stm->execute())
{
    echo "UPDATE gelukt!!";
}

}




$query = "SELECT * FROM registratie WHERE Sid = $id";
$stm = $conn->prepare($query);
if($stm->execute())
{

$Zmelding = $stm->fetch(PDO::FETCH_OBJ);
?>
<div id="Log">
<form method="POST">
    <h5>Naam: </h5><input type="text" name="txtNaam" value="<?php echo $Zmelding ->Naam; ?>" />
    <h5>Leeftijd: </h5><input type="text" name="txtleeftijd" value="<?php echo $Zmelding ->leeftijd; ?>" />
    <h5>Telefoonnummer: </h5><input type="text" name="txttelefoonnummer" value="<?php echo $Zmelding ->telefoonnummer; ?>" />
    <h5>Woonplaats: </h5><input type="text" name="txtwoonplaats" value="<?php echo $Zmelding ->woonplaats; ?>" />
    <h5>Ziekmelding: </h5><input type="text" name="txtZiekmelding" value="<?php echo $Zmelding ->Ziekmelding; ?>" />
    <h5>Ziektedatum: </h5><input type="date" name="txtZiektedatum" value="<?php echo $Zmelding ->Ziektedatum; ?>" />
    <h5>Betermelddatum: </h5><input type="date" name="txtbetermelddatum" value="<?php echo $Zmelding ->betermelddatum; ?>" />
    <h5>Opmerking: </h5><input type="text" name="txtOpmerking" value="<?php echo $Zmelding ->Opmerking; ?>" />
    <input type="submit" name="btnUpdate" id="btn" value="Update" />
</form>
</div>
<?php

	}
?>




</body>
</html>