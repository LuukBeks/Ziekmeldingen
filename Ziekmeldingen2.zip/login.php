<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Alle zieken</title>
    <link rel="stylesheet" type="text/css" href="2de.css">
</head>
<body>
<div id="btn2">
    <a href="ziekmelden.php">
        <button>Alle Leerlingen</button>
    </a>
</div>
<div id="btn2">
    <a href="registratie.php">
        <button>registratie</button>
    </a>
</div>
<h1>Ziekmelden</h1>
<?php

$host = "localhost";
$dbname = "ziekmeldingen";
$username = "root";
$password = "";

$con = new PDO("mysql:host=$host;dbname=$dbname",$username,$password);


$stm = $con->prepare("SELECT * FROM registratie WHERE Ziekmelding = 'ziek'"); 
$row = $stm->setFetchMode(PDO:: FETCH_OBJ);
$stm->execute();
?>
<br><br><br>
<table>
    <tr>
        <th><h4>Naam:  </h4></th>
        <th><h4>Leeftijd: </h4></th>
        <th><h4>Telefoonnummer: </h4></th>
        <th><h4>Woonplaats: </h4></th>
        <th><h4>ziekmelding: </h4></th>
        <th><h4>Ziektedatum: </h4></th>
        <th><h4>Betermelddatum: </h4></th>
        <th><h4>Opmerking: </h4></th>
    </tr>
    <?php
    foreach($stm->fetchAll(PDO::FETCH_OBJ) as $row){
        ?>
        <tr>
            <td><a href="Wijzigen.php?id=<?= $row->Sid ?>"><h4><?= $row->Naam ?></h4></a></td>
            <td><h4><?php echo $row->leeftijd ; ?></h4></td>
            <td><h4><?php echo $row->telefoonnummer ; ?></h4></td>
            <td><h4><?php echo $row->woonplaats ; ?></h4></td>
            <td><h4><?php echo $row->Ziekmelding ; ?></h4></td>
            <td><h4><?php echo $row->Ziektedatum ; ?></h4></td>
            <td><h4><?php echo $row->betermelddatum ; ?></h4></td>
            <td><h4><?php echo $row->Opmerking ; ?></h4></td>
        </tr>
    <?php } ?>
</table>

<br><br><br>
</body>
</html>